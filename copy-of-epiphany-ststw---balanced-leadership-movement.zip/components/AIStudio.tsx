
import React, { useState } from 'react';
import { generateText, generateImageV2, generateVideoV2 } from '../services/geminiService';

type StudioMode = 'text' | 'image' | 'video';

export const AIStudio: React.FC = () => {
  const [mode, setMode] = useState<StudioMode>('text');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ type: StudioMode; content: string } | null>(null);

  // Text Params
  const [systemInstruction, setSystemInstruction] = useState("You are the Epiphany STSTW Architect. Provide data-driven, logical societal blueprints.");
  const [temp, setTemp] = useState(0.7);
  const [topP, setTopP] = useState(0.95);
  const [topK, setTopK] = useState(64);

  // Image Params
  const [imageAspect, setImageAspect] = useState<any>("16:9");
  const [imageSize, setImageSize] = useState<any>("1K");

  // Video Params
  const [videoAspect, setVideoAspect] = useState<any>("16:9");
  const [videoRes, setVideoRes] = useState<any>("720p");

  const handleProcess = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setResult(null);

    try {
      if (mode === 'text') {
        const text = await generateText({
          prompt,
          systemInstruction,
          temperature: temp,
          topP,
          topK,
          model: 'gemini-3-flash-preview'
        });
        setResult({ type: 'text', content: text || '' });
      } else if (mode === 'image') {
        const url = await generateImageV2(prompt, imageAspect, imageSize);
        setResult({ type: 'image', content: url || '' });
      } else if (mode === 'video') {
        const url = await generateVideoV2(prompt, videoAspect, videoRes);
        setResult({ type: 'video', content: url || '' });
      }
    } catch (error: any) {
      console.error(error);
      alert("Simulation Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 lg:p-12 animate-in fade-in slide-in-from-bottom-8 duration-1000">
      <div className="flex flex-col lg:flex-row gap-12">
        {/* Controls Sidebar */}
        <div className="lg:w-1/3 space-y-8">
          <div className="glass-card rounded-[40px] p-8 border-white/10 shadow-2xl">
            <h3 className="text-2xl font-serif font-bold italic mb-6 text-white">Studio Controls</h3>
            
            <div className="flex gap-2 p-1 bg-white/5 rounded-2xl mb-8">
              {(['text', 'image', 'video'] as StudioMode[]).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mode === m ? 'bg-orange-500 text-white shadow-lg shadow-orange-950/40' : 'text-slate-500 hover:text-white'}`}
                >
                  {m}
                </button>
              ))}
            </div>

            <div className="space-y-6">
              {mode === 'text' && (
                <>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 mb-2 block">System Directive</label>
                    <textarea 
                      value={systemInstruction}
                      onChange={e => setSystemInstruction(e.target.value)}
                      className="w-full bg-black/20 border border-white/10 rounded-2xl p-4 text-xs text-slate-300 h-24 outline-none focus:ring-1 focus:ring-orange-500"
                    />
                  </div>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] font-bold text-slate-400">
                        <span>Temperature</span>
                        <span>{temp}</span>
                      </div>
                      <input type="range" min="0" max="1.5" step="0.1" value={temp} onChange={e => setTemp(parseFloat(e.target.value))} className="w-full accent-orange-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] font-bold text-slate-400">
                        <span>Top-P</span>
                        <span>{topP}</span>
                      </div>
                      <input type="range" min="0" max="1" step="0.05" value={topP} onChange={e => setTopP(parseFloat(e.target.value))} className="w-full accent-cyan-500" />
                    </div>
                  </div>
                </>
              )}

              {mode === 'image' && (
                <>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 mb-2 block">Aspect Ratio</label>
                    <select value={imageAspect} onChange={e => setImageAspect(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-sm text-white outline-none">
                      {["1:1", "4:3", "3:4", "16:9", "9:16"].map(a => <option key={a} value={a}>{a}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 mb-2 block">Resolution</label>
                    <select value={imageSize} onChange={e => setImageSize(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-sm text-white outline-none">
                      {["1K", "2K", "4K"].map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </>
              )}

              {mode === 'video' && (
                <>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 mb-2 block">Aspect Ratio</label>
                    <select value={videoAspect} onChange={e => setVideoAspect(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-sm text-white outline-none">
                      {["16:9", "9:16"].map(a => <option key={a} value={a}>{a}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 mb-2 block">Quality</label>
                    <select value={videoRes} onChange={e => setVideoRes(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-sm text-white outline-none">
                      {["720p", "1080p"].map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Workspace Area */}
        <div className="flex-grow flex flex-col gap-8">
          <div className="glass-card rounded-[40px] p-10 border-white/10 flex flex-col flex-grow shadow-2xl min-h-[600px] relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-orange-500/5 via-transparent to-transparent opacity-50" />
            
            <div className="relative z-10 flex-grow mb-8 overflow-y-auto custom-scrollbar">
              {loading ? (
                <div className="h-full flex flex-col items-center justify-center space-y-6">
                  <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin shadow-[0_0_20px_rgba(249,115,22,0.4)]" />
                  <p className="text-orange-500 font-black tracking-[0.4em] uppercase text-[10px] animate-pulse">Synchronizing Neural Channels...</p>
                </div>
              ) : result ? (
                <div className="animate-in fade-in zoom-in duration-500">
                  {result.type === 'text' && (
                    <div className="prose prose-invert max-w-none">
                      <p className="text-slate-300 text-lg leading-relaxed whitespace-pre-wrap font-medium">{result.content}</p>
                    </div>
                  )}
                  {result.type === 'image' && (
                    <div className="rounded-[40px] overflow-hidden border border-white/10 shadow-2xl ring-1 ring-white/20">
                      <img src={result.content} alt="Generated Asset" className="w-full h-auto" />
                    </div>
                  )}
                  {result.type === 'video' && (
                    <div className="rounded-[40px] overflow-hidden border border-white/10 shadow-2xl ring-1 ring-white/20">
                      <video src={result.content} controls autoPlay loop className="w-full h-auto" />
                    </div>
                  )}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center opacity-20 select-none">
                  <span className="text-[120px] font-black italic text-white/5 leading-none">STSTW</span>
                  <p className="text-[10px] font-black tracking-[1em] uppercase text-slate-500 mt-4">Awaiting Signal</p>
                </div>
              )}
            </div>

            <div className="relative">
              <textarea 
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                placeholder={`Describe the ${mode} simulation to manifest...`}
                className="w-full bg-white/5 border border-white/20 rounded-[32px] px-8 py-6 text-white text-lg outline-none focus:ring-2 focus:ring-orange-500 transition-all min-h-[140px] resize-none pr-32 font-medium"
              />
              <button 
                disabled={loading || !prompt.trim()}
                onClick={handleProcess}
                className="absolute right-4 bottom-4 bg-orange-600 hover:bg-orange-700 disabled:bg-slate-800 disabled:opacity-50 text-white px-8 py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-2xl transition-all active:scale-95"
              >
                Execute
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
