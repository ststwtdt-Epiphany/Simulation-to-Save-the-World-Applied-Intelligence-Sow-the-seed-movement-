
import React, { useState, useRef, useEffect } from 'react';
import { generateText } from '../services/geminiService';

export const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; text: string }[]>([
    { role: 'assistant', text: "Handshake complete. I am your STSTW Navigator. How can I help you understand the blueprint today?" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const text = await generateText({
        prompt: userMsg,
        model: 'gemini-3-flash-preview',
        systemInstruction: "You are the STSTW AI Navigator. You help users explore the Epiphany movement website. You are concise, logical, and visionary. You know about the Triumvirate, the Seam Ripper, and the 1,000-year plan. Keep responses helpful and professional."
      });
      setMessages(prev => [...prev, { role: 'assistant', text: text || "Signal degraded. Try again." }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', text: "Connection error. Protocol reset required." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[1000] font-sans">
      {!isOpen ? (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-gradient-to-br from-orange-500 to-fuchsia-600 rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-all group"
        >
          <div className="absolute inset-0 bg-white/20 rounded-full animate-ping group-hover:hidden" />
          <svg className="w-8 h-8 text-white relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
      ) : (
        <div className="w-80 md:w-96 glass-card rounded-[40px] border-white/20 shadow-2xl flex flex-col h-[500px] overflow-hidden animate-in slide-in-from-bottom-12 duration-500">
          <div className="p-6 border-b border-white/10 bg-white/5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-cyan-500 rounded-full animate-pulse shadow-[0_0_10px_cyan]" />
              <span className="text-[10px] font-black uppercase tracking-widest text-white">System Navigator</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-slate-500 hover:text-white transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5}/></svg>
            </button>
          </div>
          
          <div ref={scrollRef} className="flex-grow overflow-y-auto p-6 space-y-4 custom-scrollbar bg-black/40">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-2xl text-xs leading-relaxed ${m.role === 'user' ? 'bg-orange-500 text-white rounded-tr-none' : 'bg-white/10 text-slate-200 rounded-tl-none border border-white/5'}`}>
                  {m.text}
                </div>
              </div>
            ))}
            {loading && <div className="text-cyan-500 text-[10px] font-black animate-pulse tracking-widest">THINKING...</div>}
          </div>

          <div className="p-4 bg-slate-900/60 border-t border-white/10">
            <div className="relative">
              <input 
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                placeholder="Ask about STSTW..."
                className="w-full bg-white/5 border border-white/20 rounded-2xl py-3 pl-4 pr-12 text-sm text-white focus:outline-none focus:ring-1 focus:ring-orange-500"
              />
              <button 
                onClick={handleSend}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-orange-500 hover:text-orange-400"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
