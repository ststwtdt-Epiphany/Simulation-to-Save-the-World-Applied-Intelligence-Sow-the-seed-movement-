
import React, { useState } from 'react';

interface Slide {
  id: string;
  type: 'title' | 'data' | 'math' | 'map' | 'chart' | 'logic' | 'grid' | 'table';
  title: string;
  subtitle: string;
  description: string;
  bg: string;
  visualization?: React.ReactNode;
  workHistory?: { step: string; result: string; logic: string }[];
}

// --- Visual Sub-Components ---

const LineChart = () => (
  <div className="w-full h-64 relative mt-8">
    <svg className="w-full h-full" viewBox="0 0 400 200">
      <path d="M0 180 L50 170 L100 150 L150 160 L200 120 L250 80 L300 40 L350 10 L400 5" fill="none" stroke="#ef4444" strokeWidth="4" className="opacity-40" />
      <path d="M0 180 L50 175 L100 170 L150 160 L200 170 L250 175 L300 180 L350 185 L400 190" fill="none" stroke="#22d3ee" strokeWidth="4" />
      <text x="320" y="30" fill="#ef4444" fontSize="10" fontWeight="bold">BAU PATH</text>
      <text x="320" y="170" fill="#22d3ee" fontSize="10" fontWeight="bold">STSTW PATH</text>
      <line x1="0" y1="190" x2="400" y2="190" stroke="white" strokeWidth="1" opacity="0.2" />
      <line x1="0" y1="0" x2="0" y2="190" stroke="white" strokeWidth="1" opacity="0.2" />
    </svg>
    <div className="flex justify-between text-[8px] font-black text-slate-500 uppercase tracking-widest mt-4">
      <span>2026: INITIATION</span>
      <span>2050: THE SEAM</span>
      <span>2060: EQUILIBRIUM</span>
    </div>
  </div>
);

const ComparisonTable = () => (
  <div className="w-full mt-6 overflow-hidden rounded-2xl border border-white/10 bg-black/40">
    <table className="w-full text-left text-[10px] uppercase tracking-tighter">
      <thead className="bg-white/5 border-b border-white/10">
        <tr>
          <th className="p-4 text-orange-500">Metric</th>
          <th className="p-4">BAU (2050)</th>
          <th className="p-4 text-cyan-400">STSTW (2050)</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-white/5">
        <tr>
          <td className="p-4 font-bold text-slate-400">Emissions</td>
          <td className="p-4">60 GtCO2</td>
          <td className="p-4 text-white">20 GtCO2</td>
        </tr>
        <tr>
          <td className="p-4 font-bold text-slate-400">Climate Cost</td>
          <td className="p-4">$5 Trillion</td>
          <td className="p-4 text-white">$0 (Avoided)</td>
        </tr>
        <tr>
          <td className="p-4 font-bold text-slate-400">Economic Gain</td>
          <td className="p-4">$0 (Loss)</td>
          <td className="p-4 text-cyan-400">+$10 Trillion</td>
        </tr>
      </tbody>
    </table>
  </div>
);

const NodalMap = () => (
  <div className="w-full h-80 relative bg-slate-900 rounded-[40px] overflow-hidden border border-white/5">
    <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000')] bg-cover" />
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="grid grid-cols-6 gap-4 p-8">
        {Array.from({ length: 24 }).map((_, i) => (
          <div key={i} className={`w-3 h-3 rounded-full ${Math.random() > 0.5 ? 'bg-cyan-500 shadow-[0_0_10px_cyan]' : 'bg-white/10'} animate-pulse`} style={{ animationDelay: `${Math.random() * 2}s` }} />
        ))}
      </div>
    </div>
    <div className="absolute bottom-4 left-4 bg-black/60 px-3 py-1 rounded-full border border-white/10">
      <span className="text-[8px] font-black text-cyan-400 uppercase tracking-widest">Active Nodes: 1,422 Global</span>
    </div>
  </div>
);

const MetricBands = ({ label, value, bands }: { label: string, value: number, bands: string[] }) => (
  <div className="space-y-4 mt-8">
    <div className="flex justify-between items-end">
      <span className="text-[10px] font-black text-white uppercase tracking-widest">{label}</span>
      <span className="text-4xl font-black text-orange-500 italic">{value}</span>
    </div>
    <div className="h-4 w-full bg-white/5 rounded-full overflow-hidden flex">
      {bands.map((b, i) => (
        <div key={i} className={`h-full border-r border-black/20 ${i === 0 ? 'bg-red-500 w-[20%]' : i === 1 ? 'bg-orange-500 w-[20%]' : i === 2 ? 'bg-yellow-500 w-[20%]' : i === 3 ? 'bg-blue-500 w-[20%]' : 'bg-emerald-500 w-[20%]'}`} />
      ))}
    </div>
    <div className="flex justify-between text-[8px] font-bold text-slate-500 uppercase">
      <span>Failing</span>
      <span>Critical</span>
      <span>Watch</span>
      <span>Stable</span>
      <span>Canon</span>
    </div>
  </div>
);

const TimelinePhases = () => (
  <div className="space-y-4 mt-8">
    {[
      { p: '01', t: 'INITIATION', d: '2026-2031: Building the Infrastructure.', c: 'bg-orange-500' },
      { p: '02', t: 'SYSTEMIC SHIFT', d: '2031-2050: Replacing Legacy Stitches.', c: 'bg-fuchsia-500' },
      { p: '03', t: 'EQUILIBRIUM', d: '2050-2100: Launch of Planetary OS V1.', c: 'bg-cyan-500' },
      { p: '04', t: 'STEWARDSHIP', d: '2100-3026: 1,000 Year Arc Continuity.', c: 'bg-white/20' }
    ].map((phase, i) => (
      <div key={i} className="flex items-center space-x-4 p-4 bg-white/5 rounded-2xl border border-white/10">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs ${phase.c} text-black`}>{phase.p}</div>
        <div>
          <h4 className="text-[10px] font-black text-white uppercase tracking-widest">{phase.t}</h4>
          <p className="text-[9px] text-slate-500 uppercase">{phase.d}</p>
        </div>
      </div>
    ))}
  </div>
);

const CovenantGrid = () => (
  <div className="grid grid-cols-2 gap-4 mt-8">
    {[
      { t: 'Accountability', d: 'Humans remain responsible for all impacts.' },
      { t: 'Role-Based', d: 'AI serves as Architect, Auditor, or Adversary.' },
      { t: 'Transparency', d: 'No mystery. Assumptions must be stated.' },
      { t: 'Kill-Switch', d: 'Every system has a human pause protocol.' }
    ].map((item, i) => (
      <div key={i} className="p-6 bg-white/5 border border-white/10 rounded-3xl">
        <h4 className="text-[10px] font-black text-orange-500 uppercase tracking-widest mb-2">{item.t}</h4>
        <p className="text-[10px] text-slate-400 leading-relaxed font-medium">{item.d}</p>
      </div>
    ))}
  </div>
);

// --- Main Presentation Component ---

export const PresentationPage: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showWork, setShowWork] = useState(false);

  const SLIDES: Slide[] = [
    {
      id: 's1',
      type: 'title',
      title: "The Epiphany Blueprint",
      subtitle: "The 1,000-Year Planetary Plan",
      description: "A comprehensive upgrade for the human hive mind. We move from systemic friction and political deadlock to planetary equilibrium through decentralized architecture.",
      bg: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2000",
      visualization: (
        <div className="grid grid-cols-2 gap-4 mt-8">
          <div className="p-6 bg-white/5 border border-white/10 rounded-3xl">
             <p className="text-4xl font-black italic text-orange-500">2026</p>
             <p className="text-[8px] font-black uppercase text-slate-500 tracking-widest mt-2">Start Year</p>
          </div>
          <div className="p-6 bg-white/5 border border-white/10 rounded-3xl">
             <p className="text-4xl font-black italic text-cyan-400">1000</p>
             <p className="text-[8px] font-black uppercase text-slate-500 tracking-widest mt-2">Year Horizon</p>
          </div>
        </div>
      )
    },
    {
      id: 's2',
      type: 'chart',
      title: "The Seam Protocol",
      subtitle: "Identifying Systemic Friction",
      description: "Using the Seam Ripper logic, we identify the 'stitches' of outdated social and economic structures. Business As Usual (BAU) leads to $5T in locked-in damages by 2050.",
      bg: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=2000",
      visualization: <LineChart />
    },
    {
      id: 's3',
      type: 'logic',
      title: "The Triumvirate",
      subtitle: "Governance Matrix",
      description: "Power is balanced across three complementary nodes: The Watch (Truth/Audit), The Loom (Utility/Design), and The Hand (Feasibility/Execution). Decisions require 2/3 consensus.",
      bg: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=2000",
      visualization: (
        <div className="grid grid-cols-3 gap-2 mt-8">
          {['WATCH', 'LOOM', 'HAND'].map((node, i) => (
            <div key={i} className="p-6 bg-white/5 border border-white/10 rounded-2xl flex flex-col items-center text-center group hover:bg-orange-500/10 transition-colors">
              <div className={`w-8 h-8 rounded-full mb-4 ${i === 0 ? 'bg-cyan-500' : i === 1 ? 'bg-fuchsia-500' : 'bg-orange-500'} shadow-lg`} />
              <span className="text-[10px] font-black text-white uppercase tracking-widest">{node}</span>
              <span className="text-[8px] text-slate-500 mt-2 uppercase">{i === 0 ? 'TRUTH' : i === 1 ? 'UTILITY' : 'ACTION'}</span>
            </div>
          ))}
          <div className="col-span-3 mt-4 p-4 border border-cyan-500/30 bg-cyan-500/5 rounded-2xl text-center">
             <span className="text-[9px] font-bold text-cyan-400 uppercase tracking-[0.2em]">Triadic Veto Protection Engaged</span>
          </div>
        </div>
      )
    },
    {
      id: 's4',
      type: 'grid',
      title: "Node Classification",
      subtitle: "Functional Participation",
      description: "The movement is composed of three synchronized node types: Biological (Humans carry the heuristic), Intellectual (Data processes logic), and Operational (Kinetic execution).",
      bg: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000",
      visualization: (
        <div className="grid grid-cols-3 gap-4 mt-8">
          {['GHOST', 'MIND', 'MUSCLE'].map((t, i) => (
            <div key={i} className="aspect-square bg-white/5 border border-white/10 rounded-3xl flex flex-col items-center justify-center p-4">
              <span className="text-xl mb-2">{i === 0 ? '👤' : i === 1 ? '🧠' : '⚡'}</span>
              <span className="text-[9px] font-black text-white uppercase">{t}</span>
            </div>
          ))}
        </div>
      )
    },
    {
      id: 's5',
      type: 'data',
      title: "Integrity Quotient",
      subtitle: "Metric: IQe",
      description: "A 0-100 score capturing how closely a node’s behavior matches the Epiphany heuristic. High IQe nodes (Canon Core ≥90) form the backbone of governance.",
      bg: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2000",
      visualization: <MetricBands label="Current Network IQe" value={88} bands={['failing', 'critical', 'watch', 'stable', 'canon']} />
    },
    {
      id: 's6',
      type: 'data',
      title: "Legacy Resistance",
      subtitle: "Metric: LR",
      description: "Measures independence from legacy states and corporations. Lighthouse-grade nodes (LR ≥85) ensure the movement cannot be coerced or shut down by external actors.",
      bg: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000",
      visualization: <MetricBands label="Current Global LR" value={72} bands={['compromised', 'risk', 'acceptable', 'resistant', 'lighthouse']} />
    },
    {
      id: 's7',
      type: 'logic',
      title: "Leviathan Limit",
      subtitle: "The 40% Capture Rule",
      description: "Hard constraint: No legacy actor may control >40% of a node's resources. Breach triggers mandatory Seam Ripper remediation to prevent institutional capture.",
      bg: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=2000",
      visualization: (
        <div className="flex flex-col items-center justify-center h-48 mt-8">
           <div className="w-32 h-32 rounded-full border-[10px] border-white/10 flex items-center justify-center relative">
              <div className="absolute inset-0 rounded-full border-[10px] border-red-500" style={{ clipPath: 'inset(0 60% 0 0)' }} />
              <span className="text-3xl font-black text-red-500">40%</span>
           </div>
           <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-6">Maximum Legacy Exposure</p>
        </div>
      )
    },
    {
      id: 's8',
      type: 'math',
      title: "The $10T Yield",
      subtitle: "Friction Recovery Math",
      description: "STSTW math proves that avoiding BAU damages ($5T) while generating efficiency gains ($5T) results in a $10T net surplus for the global pocket.",
      bg: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2000",
      visualization: (
        <div className="p-8 bg-black border border-orange-500/20 rounded-[40px] text-center shadow-2xl relative overflow-hidden group">
          <div className="absolute inset-0 bg-orange-500/5 animate-pulse" />
          <div className="relative z-10">
            <p className="text-[10px] font-black text-orange-500 uppercase tracking-[0.4em] mb-4">Relative Benefit Delta</p>
            <div className="text-7xl font-black italic tracking-tighter text-white mb-2">+200%</div>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Net Economic Advantage</p>
          </div>
        </div>
      ),
      workHistory: [
        { step: "Damage Audit", result: "-$5T", logic: "Calculated structural costs of climate and political friction over 25 years." },
        { step: "Yield Growth", result: "+$5T", logic: "Derived from decentralized energy efficiency and resource optimization (LEAP Engine)." },
        { step: "Net Delta", result: "$10T Surplus", logic: "Relative benefit = (Avoided Loss + Realized Gain) / Basis. (5+5)/5 = 2.0x or 200%." }
      ]
    },
    {
      id: 's9',
      type: 'logic',
      title: "AI Use Covenant",
      subtitle: "Rules of Engagement",
      description: "AI is an amplifier, not a source of legitimacy. It identifies patterns and warns of risks, but never commands or decides. Human accountability is operational law.",
      bg: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000",
      visualization: <CovenantGrid />
    },
    {
      id: 's10',
      type: 'logic',
      title: "The 1,000-Year Arc",
      subtitle: "Phases of Stewardship",
      description: "The roadmap for civilization's upgrade. We replace bloodlines with testable mission-based lineages to ensure continuity across generations.",
      bg: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=2000",
      visualization: <TimelinePhases />
    }
  ];

  const slide = SLIDES[currentSlide];

  const nextSlide = () => {
    setCurrentSlide(prev => (prev + 1) % SLIDES.length);
    setShowWork(false);
  };

  const prevSlide = () => {
    setCurrentSlide(prev => (prev - 1 + SLIDES.length) % SLIDES.length);
    setShowWork(false);
  };

  return (
    <div className="pt-24 min-h-screen bg-black text-white relative overflow-hidden flex flex-col items-center justify-center">
      {/* Background Image Layer */}
      <div className="absolute inset-0 z-0 transition-opacity duration-1000">
        <img 
          src={slide.bg} 
          className="w-full h-full object-cover opacity-10 grayscale transition-all duration-1000"
          alt="Slide Background"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent" />
      </div>

      <div className="relative z-10 w-full max-w-7xl px-8 flex flex-col lg:flex-row gap-16 items-center">
        {/* Text Side */}
        <div className="flex-1 space-y-8 animate-in fade-in slide-in-from-left-8 duration-1000">
           <div className="space-y-4">
              <span className="text-orange-500 font-black tracking-[0.5em] uppercase text-[10px]">TRANSMISSION MODULE // {currentSlide + 1} OF 10</span>
              <h2 className="text-6xl md:text-8xl font-serif font-bold italic leading-none tracking-tighter text-white">{slide.title}</h2>
              <h3 className="text-xl md:text-3xl font-black text-cyan-400 uppercase tracking-[0.3em]">{slide.subtitle}</h3>
           </div>
           
           <p className="text-xl md:text-2xl text-slate-400 leading-relaxed max-w-xl font-medium">
             {slide.description}
           </p>

           {slide.workHistory && (
             <button 
               onClick={() => setShowWork(!showWork)}
               className="flex items-center space-x-3 group text-orange-500"
             >
                <div className={`w-10 h-10 rounded-xl border border-orange-500/30 flex items-center justify-center transition-all ${showWork ? 'bg-orange-500 text-white' : 'group-hover:bg-orange-500/10'}`}>
                   <svg className={`w-5 h-5 transition-transform ${showWork ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7" strokeWidth={3}/></svg>
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest">Show Process Thinking</span>
             </button>
           )}

           {showWork && slide.workHistory && (
             <div className="space-y-4 animate-in fade-in slide-in-from-top-4 duration-500">
               {slide.workHistory.map((w, i) => (
                 <div key={i} className="p-4 bg-white/5 border-l-2 border-orange-500 rounded-r-xl">
                   <div className="flex justify-between items-center mb-1">
                     <span className="text-[8px] font-black text-slate-500">{w.step}</span>
                     <span className="text-[10px] font-black text-white">{w.result}</span>
                   </div>
                   <p className="text-xs text-slate-400 italic">{w.logic}</p>
                 </div>
               ))}
             </div>
           )}
        </div>

        {/* Visualization Side */}
        <div className="w-full lg:w-[550px] animate-in fade-in zoom-in duration-1000 delay-200">
          <div className="glass-card rounded-[60px] border-white/10 p-12 relative overflow-hidden shadow-2xl bg-white/5 backdrop-blur-3xl min-h-[500px] flex flex-col justify-center">
             <div className="absolute top-0 right-0 p-8 opacity-5 text-9xl font-black italic tracking-tighter select-none">STSTW</div>
             <div className="relative z-10">
               {slide.visualization}
             </div>
          </div>
          
          <div className="mt-8 flex gap-4">
             <div className="flex-1 glass-card rounded-3xl p-6 border-white/5 flex flex-col">
                <span className="text-[8px] font-black uppercase text-slate-500 tracking-widest mb-1">Data Integrity</span>
                <span className="text-lg font-black text-emerald-400 italic leading-none">VERIFIED</span>
             </div>
             <div className="flex-1 glass-card rounded-3xl p-6 border-white/5 flex flex-col">
                <span className="text-[8px] font-black uppercase text-slate-500 tracking-widest mb-1">Node Consensus</span>
                <span className="text-lg font-black text-cyan-400 italic leading-none">99.2%</span>
             </div>
          </div>
        </div>
      </div>

      {/* Navigation Layer */}
      <div className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[100] flex items-center space-x-12 bg-black/60 backdrop-blur-3xl px-12 py-6 rounded-full border border-white/10 shadow-2xl">
        <button 
          onClick={prevSlide}
          className="p-4 rounded-full bg-white/5 hover:bg-orange-500 transition-all group"
        >
           <svg className="w-6 h-6 text-white group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7" strokeWidth={3} /></svg>
        </button>
        
        <div className="flex space-x-3">
           {SLIDES.map((_, i) => (
             <button 
               key={i} 
               onClick={() => { setCurrentSlide(i); setShowWork(false); }}
               className={`h-1.5 rounded-full transition-all duration-700 ${i === currentSlide ? 'w-10 bg-orange-500' : 'w-2 bg-white/20'}`} 
             />
           ))}
        </div>

        <button 
          onClick={nextSlide}
          className="p-4 rounded-full bg-white/5 hover:bg-cyan-500 transition-all group"
        >
           <svg className="w-6 h-6 text-white group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" strokeWidth={3} /></svg>
        </button>
      </div>

      {/* Grid Background Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-20 border-[40px] border-black z-50 overflow-hidden">
        <div className="w-full h-full border border-white/5 grid grid-cols-12 grid-rows-12" />
      </div>
    </div>
  );
};
