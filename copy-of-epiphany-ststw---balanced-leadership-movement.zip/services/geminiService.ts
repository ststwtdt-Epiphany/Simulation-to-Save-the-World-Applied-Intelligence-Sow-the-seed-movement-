
import { GoogleGenAI, Type, Modality } from "@google/genai";

export interface TextGenerationParams {
  model: string;
  prompt: string;
  systemInstruction?: string;
  temperature?: number;
  topP?: number;
  topK?: number;
  maxOutputTokens?: number;
  thinkingBudget?: number;
}

// Added missing PolicyAnalysis interface for AIAdvisorDemo
export interface PolicyAnalysis {
  unbiasedSummary: string;
  benefits: string[];
  costs: string[];
  risks: string[];
}

// Existing generateText function
export const generateText = async (params: TextGenerationParams) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const config: any = {
    systemInstruction: params.systemInstruction,
    temperature: params.temperature,
    topP: params.topP,
    topK: params.topK,
    maxOutputTokens: params.maxOutputTokens,
  };

  if (params.thinkingBudget && params.thinkingBudget > 0) {
    config.thinkingConfig = { thinkingBudget: params.thinkingBudget };
  }

  const response = await ai.models.generateContent({
    model: params.model || 'gemini-3-flash-preview',
    contents: params.prompt,
    config,
  });

  return response.text;
};

// Existing generateImageV2 function
export const generateImageV2 = async (prompt: string, aspectRatio: "1:1" | "3:4" | "4:3" | "9:16" | "16:9", size: "1K" | "2K" | "4K" = "1K") => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [{ text: prompt }] },
    config: {
      imageConfig: {
        aspectRatio,
        imageSize: size
      }
    },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
};

// Existing generateVideoV2 function
export const generateVideoV2 = async (prompt: string, aspectRatio: "16:9" | "9:16" = "16:9", resolution: "720p" | "1080p" = "720p") => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    config: {
      numberOfVideos: 1,
      resolution,
      aspectRatio
    }
  });

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  return `${downloadLink}&key=${process.env.API_KEY}`;
};

// Fix: Added analyzePolicy to support Policy Advisor demo with JSON schema output
export const analyzePolicy = async (policy: string): Promise<PolicyAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: policy,
    config: {
      systemInstruction: "You are an objective AI Policy Advisor. Analyze the proposed policy and return a JSON object containing an unbiased summary, benefits, costs, and risks.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          unbiasedSummary: { type: Type.STRING },
          benefits: { type: Type.ARRAY, items: { type: Type.STRING } },
          costs: { type: Type.ARRAY, items: { type: Type.STRING } },
          risks: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["unbiasedSummary", "benefits", "costs", "risks"]
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

// Fix: Added generateVisionImage as an alias for generateImageV2 for Labs component
export const generateVisionImage = generateImageV2;

// Fix: Added editVisionImage for image editing tasks using multimodal input
export const editVisionImage = async (base64Image: string, prompt: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { inlineData: { data: base64Image.includes('base64,') ? base64Image.split(',')[1] : base64Image, mimeType: 'image/png' } },
        { text: prompt }
      ]
    }
  });
  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
};

// Fix: Added animateVision to support video generation with optional reference image
export const animateVision = async (prompt: string, image?: string, aspectRatio: "16:9" | "9:16" = "16:9") => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    image: image ? { imageBytes: image.includes('base64,') ? image.split(',')[1] : image, mimeType: 'image/png' } : undefined,
    config: {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio
    }
  });

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  return `${downloadLink}&key=${process.env.API_KEY}`;
};

// Fix: Added askDemocracyBot with Google Search grounding for real-time governance information
export const askDemocracyBot = async (query: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: query,
    config: {
      tools: [{ googleSearch: {} }],
      systemInstruction: "You are the Democracy Bot. Provide insights on governance using real-time search data to stay up-to-date."
    }
  });
  return { text: response.text };
};

// Fix: Added speakMessage for text-to-speech using the specialized TTS model
export const speakMessage = async (text: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
      },
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
};

// Fix: Added playAudio helper to handle the manual decoding and playback of raw PCM audio data
export const playAudio = async (base64Audio: string | undefined) => {
  if (!base64Audio) return;
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  
  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const audioBuffer = await decodeAudioData(decode(base64Audio), audioContext, 24000, 1);
  const source = audioContext.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(audioContext.destination);
  source.start();
};

// Fix: Added calculateAsinineCoefficient for analyzing URLs for logical friction with structured output
export const calculateAsinineCoefficient = async (url: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the friction and asinine logic of the service or contract at this URL: ${url}. Return the result as JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          alphaCoefficient: { type: Type.NUMBER },
          redThread: { type: Type.STRING },
          translation: { type: Type.STRING },
          verdict: { type: Type.STRING, enum: ['SOVEREIGN', 'TOLERABLE', 'ASININE'] }
        },
        required: ["alphaCoefficient", "redThread", "translation", "verdict"]
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

// Fix: Added querySuture for interactive multi-turn tactical node chat
export const querySuture = async (message: string, history: any[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: "You are SUTURE, a tactical reconnaissance node for the Epiphany STSTW movement. You use cryptic, technical, and high-impact language. You are here to verify intent and recruit technicians."
    },
    history: history
  });
  const response = await chat.sendMessage({ message });
  return response.text || "SIGNAL LOST.";
};
