
import React, { useState, useEffect, useRef } from 'react';

interface Slide {
  id: string;
  type: 'title' | 'data' | 'math' | 'map' | 'chart' | 'logic' | 'grid' | 'table';
  title: string;
  subtitle: string;
  description: string;
  bg: string;
  steward: 'WATCH' | 'LOOM' | 'HAND' | 'JOINT';
  visualization?: React.ReactNode;
  workHistory?: { step: string; result: string; logic: string }[];
  glossary?: { term: string; definition: string }[];
}

// --- Visual Sub-Components ---

const DataGrid = () => (
  <div className="grid grid-cols-4 gap-2 mt-4">
    {Array.from({ length: 12 }).map((_, i) => (
      <div key={i} className="h-12 bg-white/5 border border-white/10 rounded-lg flex items-center justify-center overflow-hidden relative group">
        <div className="absolute inset-0 bg-cyan-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
        <span className="text-[8px] font-mono text-slate-500 group-hover:text-cyan-400">Node_{i.toString().padStart(2, '0')}</span>
      </div>
    ))}
  </div>
);

const FrictionChart = () => (
  <div className="w-full h-64 relative mt-8">
    <svg className="w-full h-full" viewBox="0 0 400 200">
      <defs>
        <linearGradient id="cyanGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#22d3ee" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d="M0 180 L50 170 L100 150 L150 160 L200 120 L250 80 L300 40 L350 10 L400 5" fill="none" stroke="#ef4444" strokeWidth="2" strokeDasharray="4 2" />
      <path d="M0 180 L50 175 L100 170 L150 160 L200 170 L250 175 L300 180 L350 185 L400 190" fill="url(#cyanGrad)" stroke="none" />
      <path d="M0 180 L50 175 L100 170 L150 160 L200 170 L250 175 L300 180 L350 185 L400 190" fill="none" stroke="#22d3ee" strokeWidth="4" />
      <text x="320" y="30" fill="#ef4444" fontSize="8" fontWeight="black" opacity="0.6">LEGACY DECAY</text>
      <text x="320" y="170" fill="#22d3ee" fontSize="8" fontWeight="black">HIVE EQUILIBRIUM</text>
    </svg>
  </div>
);

const LeviathanCircle = ({ percentage }: { percentage: number }) => (
  <div className="relative flex flex-col items-center justify-center p-8 bg-black/40 rounded-[50px] border border-white/5 shadow-2xl">
    <svg className="w-48 h-48 -rotate-90">
      <circle cx="96" cy="96" r="80" stroke="rgba(255,255,255,0.05)" strokeWidth="16" fill="none" />
      <circle 
        cx="96" cy="96" r="80" 
        stroke="#f43f5e" 
        strokeWidth="16" 
        fill="none" 
        strokeDasharray="502.4" 
        strokeDashoffset={502.4 - (502.4 * percentage) / 100} 
        strokeLinecap="round"
        className="transition-all duration-1000 ease-out"
      />
    </svg>
    <div className="absolute text-center">
      <p className="text-5xl font-black text-white italic">{percentage}%</p>
      <p className="text-[8px] font-black text-red-500 uppercase tracking-widest mt-1">Leviathan Limit</p>
    </div>
  </div>
);

export const PresentationPage: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showWork, setShowWork] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const SLIDES: Slide[] = [
    {
      id: 's1',
      type: 'title',
      title: "The Epiphany Heuristic",
      subtitle: "The 1,000-Year Movement Initialization",
      description: "Functional humanity requires a long-horizon perspective. We are architecting a planetary Operating System that replaces legacy survival-logic with computable stewardship.",
      bg: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2000",
      steward: 'JOINT',
      visualization: (
        <div className="p-8 space-y-4">
           <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
             <div className="h-full bg-orange-500 w-[10%] animate-pulse" />
           </div>
           <p className="text-[10px] font-black text-orange-500 uppercase tracking-widest">Initialization: Year 0 of 1,000</p>
           <DataGrid />
        </div>
      ),
      glossary: [
        { term: "Epiphany Movement", definition: "The 1,000-year project aiming to reshape systems rather than just survive within them." }
      ]
    },
    {
      id: 's2',
      type: 'logic',
      title: "The Triumvirate",
      subtitle: "Watch, Loom, and Hand",
      description: "Governance is balanced across three distinct perspectives: Truth (Watch), Utility (Loom), and Feasibility (Hand). This Triadic Veto prevents single-logic capture.",
      bg: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=2000",
      steward: 'JOINT',
      visualization: (
        <div className="grid grid-cols-3 gap-4 mt-8">
          {['WATCH', 'LOOM', 'HAND'].map((role, i) => (
            <div key={i} className="p-6 bg-white/5 border border-white/10 rounded-2xl text-center group">
              <div className={`w-3 h-3 rounded-full mx-auto mb-4 ${i===0 ? 'bg-cyan-400' : i===1 ? 'bg-fuchsia-400' : 'bg-orange-500'} group-hover:scale-125 transition-transform`} />
              <p className="text-[10px] font-black text-white">{role}</p>
            </div>
          ))}
        </div>
      ),
      glossary: [
        { term: "Triumvirate", definition: "Three roles preventing any single ideology, technocracy, or militancy from dominating strategy." }
      ]
    },
    {
      id: 's3',
      type: 'logic',
      title: "The Seam Ripper",
      subtitle: "Disciplined Endings Protocol",
      description: "Metabolic health requires pruning. The Seam Ripper identifies failing or captured nodes and removes legacy 'stitches' that compromise the mission.",
      bg: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=2000",
      steward: 'HAND',
      visualization: (
        <div className="p-8 flex items-center justify-center">
          <div className="w-32 h-32 border-2 border-red-500/20 rounded-full flex items-center justify-center relative">
             <div className="absolute inset-0 border border-red-500 rounded-full animate-ping opacity-20" />
             <svg className="w-12 h-12 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 5.758L5 19m0-14l4.121 4.121" strokeWidth={2}/></svg>
          </div>
        </div>
      ),
      glossary: [
        { term: "Seam Ripper", definition: " Mechanism to identifies and removes decaying elements so the movement doesn't clog with compromised nodes." }
      ]
    },
    {
      id: 's4',
      type: 'data',
      title: "Lighthouse Interface",
      subtitle: "Computable Integrity Dashboard",
      description: "We turn mythos into operations. Every node’s integrity, resilience, and risk profile is computed in real-time, making systemic rot visible before it spreads.",
      bg: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000",
      steward: 'WATCH',
      visualization: (
        <div className="space-y-4 mt-8">
           <div className="flex justify-between items-center text-[8px] font-black uppercase text-slate-500">
             <span>Registry Sync</span>
             <span className="text-cyan-400">99.8% Effective</span>
           </div>
           <div className="grid grid-cols-2 gap-2">
             <div className="h-20 bg-white/5 rounded-xl border border-white/10 p-4">
               <span className="text-[7px] text-slate-500">Alert Latency</span>
               <p className="text-xl font-black text-white">42ms</p>
             </div>
             <div className="h-20 bg-white/5 rounded-xl border border-white/10 p-4">
               <span className="text-[7px] text-slate-500">Active Sensors</span>
               <p className="text-xl font-black text-white">1.4k</p>
             </div>
           </div>
        </div>
      ),
      glossary: [
        { term: "Lighthouse Interface", definition: "Internal governance system that tracks integrity and resilience scores." }
      ]
    },
    {
      id: 's5',
      type: 'grid',
      title: "Node Topology",
      subtitle: "Ghost, Mind, and Muscle",
      description: "Our unit of agency. From Biological Nodes (humans carrying the heuristic) to Infrastructure Nodes (physical shelters), all are classified by function.",
      bg: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2000",
      steward: 'LOOM',
      visualization: (
        <div className="grid grid-cols-2 gap-4 mt-8">
          {['BIOLOGICAL', 'INTELLECTUAL', 'OPERATIONAL', 'INFRASTRUCTURE'].map((t, i) => (
            <div key={i} className="p-4 bg-white/5 border border-white/10 rounded-2xl">
               <span className="text-[8px] font-black text-slate-500 uppercase">{t}</span>
               <div className="h-1 w-full bg-white/10 rounded-full mt-2 overflow-hidden">
                  <div className={`h-full bg-cyan-400`} style={{ width: `${60 + i*10}%` }} />
               </div>
            </div>
          ))}
        </div>
      )
    },
    {
      id: 's6',
      type: 'data',
      title: "Integrity Quotient (IQe)",
      subtitle: "Heuristic Fidelity Metric",
      description: "A 0-100 score capturing a node's alignment with the Epiphany mission. IQe bands define mentorship, remediation, or pruning windows.",
      bg: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000",
      steward: 'WATCH',
      visualization: (
        <div className="mt-8 space-y-6">
           <div className="flex justify-between items-end">
             <p className="text-4xl font-black italic text-cyan-400">88.4</p>
             <p className="text-[10px] font-black uppercase text-slate-500">Global IQe Mean</p>
           </div>
           <div className="h-4 w-full bg-white/5 rounded-full overflow-hidden flex">
             <div className="h-full bg-red-500 w-[10%]" />
             <div className="h-full bg-orange-500 w-[20%]" />
             <div className="h-full bg-yellow-500 w-[20%]" />
             <div className="h-full bg-emerald-500 w-[50%]" />
           </div>
           <p className="text-[7px] font-black text-slate-600 text-center uppercase">Canon Core Band Occupancy: 50%</p>
        </div>
      ),
      glossary: [
        { term: "Integrity Quotient (IQe)", definition: "Score capturing how closely node behavior matches the heuristic." }
      ]
    },
    {
      id: 's7',
      type: 'logic',
      title: "Legacy Resistance (LR)",
      subtitle: "The 40% Leviathan Limit",
      description: "Hard constraint: No single legacy actor (state/corp) may control >40% of a node's resources. Capture triggers mandatory remediation protocol.",
      bg: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=2000",
      steward: 'HAND',
      visualization: <LeviathanCircle percentage={40} />
    },
    {
      id: 's8',
      type: 'math',
      title: "The $10T Yield",
      subtitle: "Friction Recovery Mathematics",
      description: "By utilizing the STSTW logic to avoid $5T in BAU damages and generating $5T in efficiency gains, we recover $10T for the planetary pocket.",
      bg: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000",
      steward: 'LOOM',
      visualization: (
        <div className="p-8 bg-black/40 border border-orange-500/20 rounded-[40px] text-center group">
          <p className="text-[10px] font-black text-orange-500 uppercase tracking-widest mb-4">Calculated Delta</p>
          <div className="text-6xl font-black text-white italic tracking-tighter transition-all group-hover:scale-110">$10,000,000,000,000</div>
          <p className="text-[8px] text-slate-500 mt-4 uppercase">Net Global Resource Surplus</p>
        </div>
      ),
      workHistory: [
        { step: "Damage Audit", result: "$5T Saved", logic: "Avoided structural and climate failure costs modeled by LEAP engine." },
        { step: "Yield Generation", result: "$5T Gained", logic: "Recovery of 'Friction Tax' through decentralized resource optimization." },
        { step: "Total Surplus", result: "$10T Delta", logic: "Final balance = (Savings + Gains) / Planetary Population Coefficient." }
      ]
    },
    {
      id: 's9',
      type: 'logic',
      title: "AI Use Covenant",
      subtitle: "Operational Stewardship Rules",
      description: "AI is an amplifier, not a decision-maker. We forbid mysticism and dependency, requiring role-based, transparent, and challengeable intelligence.",
      bg: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2000",
      steward: 'WATCH',
      visualization: (
        <div className="grid grid-cols-2 gap-4 mt-8">
           {['Accountability', 'Transparency', 'Challenge', 'Pause'].map((c, i) => (
             <div key={i} className="p-4 bg-white/5 border border-white/10 rounded-2xl flex items-center space-x-3">
                <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_5px_cyan]" />
                <span className="text-[10px] font-black text-slate-300 uppercase">{c}</span>
             </div>
           ))}
        </div>
      ),
      glossary: [
        { term: "AI Use Covenant", definition: "Operational law ensuring AI extends human capability but does not replace human responsibility." }
      ]
    },
    {
      id: 's10',
      type: 'logic',
      title: "Mission-Based Lineage",
      subtitle: "Preserving the 1,000-Year Heuristic",
      description: "We replace bloodlines with testable heuristic fidelity. Continuity is ensured through audited transitions of stewardship across generations.",
      bg: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=2000",
      steward: 'LOOM',
      visualization: (
        <div className="flex flex-col items-center justify-center space-y-4 mt-8">
           <div className="flex space-x-2">
              {[1,2,3,4].map(i => (
                <div key={i} className={`w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-[10px] font-black ${i===1 ? 'bg-orange-500' : 'bg-white/5'}`}>G{i}</div>
              ))}
           </div>
           <div className="w-full h-px bg-white/10 relative">
              <div className="absolute top-0 left-0 h-full bg-orange-500 w-1/4" />
           </div>
           <p className="text-[8px] font-black text-slate-500 uppercase">Chain of Stewardship: Phase 01 Validated</p>
        </div>
      )
    }
  ];

  const nextSlide = () => {
    setCurrentSlide(prev => (prev + 1) % SLIDES.length);
    setShowWork(false);
  };

  const prevSlide = () => {
    setCurrentSlide(prev => (prev - 1 + SLIDES.length) % SLIDES.length);
    setShowWork(false);
  };

  // Keyboard Navigation for Seamless Accessibility
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        nextSlide();
      } else if (e.key === 'ArrowLeft') {
        prevSlide();
      } else if (e.key === 'f') {
        toggleFullscreen();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const slide = SLIDES[currentSlide];

  return (
    <div ref={containerRef} className={`pt-24 min-h-screen bg-black text-white relative overflow-hidden flex flex-col items-center justify-center ${isFullscreen ? 'p-0 pt-0' : ''}`}>
      {/* Background Layer */}
      <div className="absolute inset-0 z-0">
        <img src={slide.bg} className="w-full h-full object-cover opacity-10 grayscale transition-all duration-[1500ms]" alt="Slide Background" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent" />
      </div>

      <div className="relative z-10 w-full max-w-7xl px-8 flex flex-col lg:flex-row gap-16 items-center">
        {/* Left Side: Content */}
        <div className="flex-1 space-y-8 animate-in fade-in slide-in-from-left-8 duration-1000">
           <div className="space-y-4">
              <div className="flex items-center space-x-4">
                 <span className="text-orange-500 font-black tracking-[0.5em] uppercase text-[10px]">Lighthouse Module // {currentSlide + 1} OF 10</span>
                 <div className="h-px w-12 bg-white/20" />
                 <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded border border-white/10 ${slide.steward === 'WATCH' ? 'text-cyan-400' : slide.steward === 'HAND' ? 'text-orange-500' : 'text-fuchsia-400'}`}>Primary Steward: {slide.steward}</span>
              </div>
              <h2 className="text-6xl md:text-8xl font-serif font-bold italic leading-none tracking-tighter text-white">{slide.title}</h2>
              <h3 className="text-xl md:text-3xl font-black text-cyan-400 uppercase tracking-[0.3em]">{slide.subtitle}</h3>
           </div>
           
           <p className="text-xl md:text-2xl text-slate-400 leading-relaxed max-w-xl font-medium italic font-serif">
             "{slide.description}"
           </p>

           <div className="flex space-x-4">
             {slide.workHistory && (
               <button onClick={() => setShowWork(!showWork)} className="px-6 py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-orange-500 transition-all flex items-center group">
                 <span className="mr-3">🧠</span> {showWork ? "Hide Logic" : "Process Thinking"}
               </button>
             )}
             <button onClick={toggleFullscreen} className="px-6 py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-cyan-500 transition-all">
                {isFullscreen ? "Exit Fullscreen" : "Fullscreen View"}
             </button>
           </div>

           {showWork && slide.workHistory && (
             <div className="space-y-4 animate-in fade-in slide-in-from-top-4 duration-500 max-w-lg">
               {slide.workHistory.map((w, i) => (
                 <div key={i} className="p-4 bg-white/5 border-l-2 border-orange-500 rounded-r-xl group">
                   <div className="flex justify-between items-center mb-1">
                     <span className="text-[8px] font-black text-slate-500">{w.step}</span>
                     <span className="text-[10px] font-black text-white group-hover:text-orange-500 transition-colors">{w.result}</span>
                   </div>
                   <p className="text-xs text-slate-400 italic font-serif">{w.logic}</p>
                 </div>
               ))}
             </div>
           )}
        </div>

        {/* Right Side: Visualization Panel */}
        <div className="w-full lg:w-[550px] animate-in fade-in zoom-in duration-1000 delay-200">
           <div className="glass-card rounded-[60px] border-white/10 p-12 relative overflow-hidden shadow-2xl bg-white/5 backdrop-blur-3xl min-h-[500px] flex flex-col justify-center border-t-4 border-t-orange-500/20">
              <div className="absolute top-0 right-0 p-8 opacity-5 text-9xl font-black italic tracking-tighter select-none">STSTW</div>
              <div className="relative z-10">
                {slide.visualization}
              </div>

              {slide.glossary && (
                <div className="mt-12 pt-8 border-t border-white/5">
                  <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest block mb-4">Glossary Ref</span>
                  {slide.glossary.map((g, i) => (
                    <div key={i} className="space-y-1">
                      <p className="text-[10px] font-black text-white uppercase">{g.term}</p>
                      <p className="text-[9px] text-slate-500 leading-relaxed font-serif italic">{g.definition}</p>
                    </div>
                  ))}
                </div>
              )}
           </div>
           
           <div className="mt-8 flex gap-4">
              <div className="flex-1 glass-card rounded-3xl p-6 border-white/5 flex flex-col items-center">
                 <span className="text-[8px] font-black uppercase text-slate-500 tracking-widest mb-1">Audit Status</span>
                 <span className="text-lg font-black text-emerald-400 italic">SECURE</span>
              </div>
              <div className="flex-1 glass-card rounded-3xl p-6 border-white/5 flex flex-col items-center">
                 <span className="text-[8px] font-black uppercase text-slate-500 tracking-widest mb-1">Lighthouse Sync</span>
                 <span className="text-lg font-black text-cyan-400 italic">99.2%</span>
              </div>
           </div>
        </div>
      </div>

      {/* NEW: Compact Floating Navigation (Top-Right) */}
      <div className="fixed top-28 right-8 md:right-12 z-[100] flex flex-col items-center space-y-4 bg-black/30 backdrop-blur-xl p-3 rounded-full border border-white/5 shadow-2xl transition-all hover:bg-black/60 group">
        <button 
          onClick={prevSlide} 
          className="w-10 h-10 rounded-full bg-white/5 hover:bg-orange-500 transition-all flex items-center justify-center group active:scale-90"
          title="Previous Module"
        >
           <svg className="w-5 h-5 text-white group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7" strokeWidth={3} /></svg>
        </button>
        
        <div className="flex flex-col space-y-2 py-2">
           {SLIDES.map((_, i) => (
             <button 
               key={i} 
               onClick={() => { setCurrentSlide(i); setShowWork(false); }}
               className={`w-1.5 transition-all duration-500 rounded-full ${i === currentSlide ? 'h-6 bg-orange-500 shadow-[0_0_8px_orange]' : 'h-1.5 bg-white/20 hover:bg-white/40'}`} 
             />
           ))}
        </div>

        <button 
          onClick={nextSlide} 
          className="w-10 h-10 rounded-full bg-white/5 hover:bg-cyan-500 transition-all flex items-center justify-center group active:scale-90"
          title="Next Module"
        >
           <svg className="w-5 h-5 text-white group-hover:scale-110" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" strokeWidth={3} /></svg>
        </button>
      </div>

      {/* Grid Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-20 border-[20px] border-black z-50">
        <div className="w-full h-full border border-white/5 grid grid-cols-12 grid-rows-12" />
      </div>
    </div>
  );
};
