
import React, { useState, useEffect } from 'react';
import { FailureEntry, DissentSignal } from '../types';
import { generateText } from '../services/geminiService';

const FAILURE_LEDGER: FailureEntry[] = [
  { id: 'f1', cycle: 'C1.2026', action: 'Initial Node A/B Binary Election', result: '32% Friction Spike', logic: 'Voter verification bottleneck due to legacy ID dependencies.', adjustment: 'Implemented Seam Ripper to bypass legacy ID stitches via NFC hardware.' },
  { id: 'f2', cycle: 'C2.2027', action: 'Direct Health Allocation Beta', result: 'Resource Misthreading', logic: 'AI Advisor overestimated infrastructure node capacity in rural sectors.', adjustment: 'Added "Moral Load" buffer to human health metrics.' },
  { id: 'f3', cycle: 'C1.2028', action: 'Public Simulation Access', result: 'DDOS (Intellectual Drift)', logic: 'Opposition nodes simulated invalid catastrophic paths to skew heuristic.', adjustment: 'Enhanced "Fact Mirror" with Immutable Hashing for input integrity.' }
];

const LIGHTHOUSE_STATS = [
  { label: 'Canon Core Nodes', value: '42%', color: 'bg-orange-500' },
  { label: 'Lighthouse LR Nodes', value: '28%', color: 'bg-cyan-500' },
  { label: 'Watch Zone Nodes', value: '18%', color: 'bg-yellow-500' },
  { label: 'Critical Remediation', value: '12%', color: 'bg-red-500' }
];

export const ArchitecturePage: React.FC = () => {
  const [horizon, setHorizon] = useState(2026);
  const [moralWeather, setMoralWeather] = useState('CLEAR');
  const [dissentText, setDissentText] = useState('');
  const [signals, setSignals] = useState<DissentSignal[]>([
    { id: 'd1', source: '@Anonymous', friction: 'The 40% Leviathan limit is too high for tech sectors.', signalStrength: 82, status: 'INTEGRATED' },
    { id: 'd2', source: '@Recruit_04', friction: 'Lack of biological node representation in Node C.', signalStrength: 64, status: 'PENDING' }
  ]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleDissent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dissentText.trim() || isProcessing) return;
    setIsProcessing(true);

    try {
        // Use Gemini to refine dissent into architectural signal
        const refined = await generateText({
            prompt: `Refine this user dissent into a professional architectural friction signal for a 1,000-year plan: "${dissentText}"`,
            systemInstruction: "You are the Epiphany Legibility Engine. Translate raw frustration into computable signals.",
            model: 'gemini-3-flash-preview'
        });

        const newSignal: DissentSignal = {
            id: Date.now().toString(),
            source: '@Node_Input',
            friction: refined || dissentText,
            signalStrength: Math.floor(Math.random() * 40) + 60,
            status: 'PENDING'
        };
        setSignals([newSignal, ...signals]);
        setDissentText('');
    } catch (err) {
        alert("Signal Transmission Failed.");
    } finally {
        setIsProcessing(false);
    }
  };

  return (
    <div className="pt-32 pb-24 bg-slate-950 text-white min-h-screen relative overflow-hidden font-sans">
      {/* Background Ambience */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-orange-500/5 rounded-full blur-[160px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-cyan-500/5 rounded-full blur-[140px] pointer-events-none" />
      </div>

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        {/* Header Section */}
        <div className="mb-20 text-center lg:text-left border-l-4 border-orange-500 pl-10">
          <span className="text-orange-500 font-black tracking-[0.4em] uppercase text-[10px] mb-4 block">Core Organs // V1.0.4</span>
          <h1 className="text-5xl md:text-8xl font-serif font-bold italic mb-6 leading-none tracking-tighter">System <span className="gradient-text">Organs</span></h1>
          <p className="text-xl text-slate-400 max-w-3xl font-medium leading-relaxed">
            A civilization prototype requires anti-fragility. These organs ensure the Epiphany OS doesn't just run—it evolves through friction, failure, and time.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-10">
          {/* LEFT COLUMN: Ledger & Dissent */}
          <div className="lg:col-span-7 space-y-10">
            
            {/* Failure Ledger Organ */}
            <section className="glass-card rounded-[40px] p-10 border-white/5 relative overflow-hidden group">
               <div className="absolute top-0 right-0 p-8 opacity-5 text-4xl font-black italic">LEDGER</div>
               <div className="flex justify-between items-center mb-8">
                  <h2 className="text-2xl font-black uppercase tracking-widest text-white">Failure Archive</h2>
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-3 py-1 bg-white/5 rounded-full">Integrity: Immutable</span>
               </div>
               <div className="space-y-6">
                  {FAILURE_LEDGER.map(entry => (
                    <div key={entry.id} className="p-6 bg-white/5 border border-white/10 rounded-3xl hover:border-red-500/30 transition-all group/item">
                       <div className="flex justify-between items-start mb-4">
                          <span className="text-[10px] font-black text-red-500 uppercase tracking-widest">{entry.cycle} // {entry.action}</span>
                          <span className="text-xs font-bold text-white italic">{entry.result}</span>
                       </div>
                       <p className="text-sm text-slate-400 leading-relaxed font-serif italic mb-4">"{entry.logic}"</p>
                       <div className="pt-4 border-t border-white/5">
                          <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Adjustment: {entry.adjustment}</p>
                       </div>
                    </div>
                  ))}
               </div>
            </section>

            {/* Dissent Interface Organ */}
            <section className="glass-card rounded-[40px] p-10 border-white/5 bg-black/40 relative overflow-hidden">
               <h2 className="text-2xl font-black uppercase tracking-widest text-white mb-8">Dissent Interface</h2>
               <form onSubmit={handleDissent} className="relative mb-12">
                  <textarea 
                    value={dissentText}
                    onChange={e => setDissentText(e.target.value)}
                    placeholder="Submit friction... Challenge an assumption."
                    className="w-full h-32 bg-white/5 border border-white/10 rounded-3xl p-6 text-white outline-none focus:ring-1 focus:ring-fuchsia-500 resize-none font-medium mb-4"
                  />
                  <button 
                    disabled={isProcessing || !dissentText.trim()}
                    className="absolute right-4 bottom-8 bg-fuchsia-600 hover:bg-fuchsia-700 text-white px-8 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-xl active:scale-95 disabled:opacity-30"
                  >
                    {isProcessing ? 'Processing Signal...' : 'Transmit Signal'}
                  </button>
               </form>
               <div className="space-y-4">
                  {signals.map(s => (
                    <div key={s.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                       <div className="flex-grow">
                          <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">{s.source} // Signal: {s.signalStrength}%</span>
                          <p className="text-xs text-slate-300 font-medium leading-relaxed">{s.friction}</p>
                       </div>
                       <div className={`ml-4 px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${s.status === 'INTEGRATED' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-orange-500/20 text-orange-400'}`}>
                          {s.status}
                       </div>
                    </div>
                  ))}
               </div>
            </section>
          </div>

          {/* RIGHT COLUMN: Time & Stats */}
          <div className="lg:col-span-5 space-y-10">
            
            {/* Temporal Lens Organ */}
            <section className="glass-card rounded-[40px] p-10 border-white/10 bg-gradient-to-br from-slate-900 to-slate-950 relative overflow-hidden">
               <div className="absolute top-0 right-0 p-8 opacity-5 text-4xl font-black italic">TIME</div>
               <h2 className="text-2xl font-black uppercase tracking-widest text-white mb-2">Temporal Lens</h2>
               <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-10">Long-Horizon Simulation Slider</p>
               
               <div className="space-y-12">
                  <div className="relative pt-10">
                     <div className="absolute top-0 left-0 w-full flex justify-between px-2">
                        <span className="text-[10px] font-black text-orange-500">2026</span>
                        <span className="text-[10px] font-black text-cyan-400">3026</span>
                     </div>
                     <input 
                       type="range" 
                       min="2026" 
                       max="3026" 
                       step="5" 
                       value={horizon}
                       onChange={e => {
                          const val = parseInt(e.target.value);
                          setHorizon(val);
                          setMoralWeather(val > 2500 ? 'STABLE' : val > 2100 ? 'TURBULENT' : 'CALIBRATING');
                       }}
                       className="w-full h-2 bg-white/10 rounded-full appearance-none accent-orange-500 cursor-pointer"
                     />
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                     <div className="p-6 bg-white/5 rounded-[32px] border border-white/5">
                        <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Active Horizon</span>
                        <p className="text-3xl font-black text-white italic">{horizon}</p>
                     </div>
                     <div className="p-6 bg-white/5 rounded-[32px] border border-white/5">
                        <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Moral Load Weather</span>
                        <p className={`text-xl font-black italic ${moralWeather === 'TURBULENT' ? 'text-orange-500' : 'text-cyan-400'}`}>{moralWeather}</p>
                     </div>
                  </div>

                  <div className="p-8 bg-black/40 border border-white/10 rounded-[32px]">
                     <h4 className="text-[10px] font-black text-white uppercase tracking-widest mb-4">Horizon Projection</h4>
                     <p className="text-xs text-slate-400 leading-relaxed italic font-serif">
                        {horizon < 2100 ? '"Foundational hardening. Legacy resistance is the priority. 40% Limit is the primary constraint."' : 
                         horizon < 2500 ? '"Expansion Phase. Decoupling from nation-state survival logic complete. Planetary OS operating at scale."' : 
                         '"Stewardship Phase. Biological node lineage preservation and long-horizon heuristic fidelity ensured."'}
                     </p>
                  </div>
               </div>
            </section>

            {/* Public Lighthouse Organ */}
            <section className="glass-card rounded-[40px] p-10 border-white/5 bg-slate-900/40 relative overflow-hidden">
               <h2 className="text-2xl font-black uppercase tracking-widest text-white mb-2">Public Lighthouse</h2>
               <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-10">Aggregated Network Integrity</p>
               
               <div className="space-y-6">
                  {LIGHTHOUSE_STATS.map(stat => (
                    <div key={stat.label} className="space-y-2">
                       <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                          <span className="text-slate-400">{stat.label}</span>
                          <span className="text-white">{stat.value}</span>
                       </div>
                       <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                          <div className={`h-full ${stat.color}`} style={{ width: stat.value }} />
                       </div>
                    </div>
                  ))}
               </div>

               <div className="mt-12 pt-8 border-t border-white/5 flex items-center justify-between">
                  <div>
                    <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Global Drift Indicator</span>
                    <p className="text-xs font-black text-emerald-400 uppercase">SIGNAL_NORMAL</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Last Sync</span>
                    <p className="text-xs font-black text-white uppercase">42s ago</p>
                  </div>
               </div>
            </section>

            {/* Legibility Engine (Rite of Exit) */}
            <section className="glass-card rounded-[40px] p-10 border-white/5 bg-white/5 group hover:bg-white/10 transition-all cursor-pointer">
               <h2 className="text-2xl font-black uppercase tracking-widest text-white mb-2">Rite of Exit</h2>
               <p className="text-xs text-slate-400 font-medium mb-6">A system is only as free as its exit pathway. Audit the formal path to node decommissioning.</p>
               <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-white/20 transition-all">
                     <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" strokeWidth={2.5}/></svg>
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-white group-hover:text-orange-500">Review Protocol</span>
               </div>
            </section>

          </div>
        </div>
      </div>
    </div>
  );
};
